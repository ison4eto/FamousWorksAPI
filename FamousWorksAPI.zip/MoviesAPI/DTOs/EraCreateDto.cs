﻿namespace FamousWorksAPI.DTOs
{
    public class EraCreateDto
    {
        public string Name { get; set; }
    }
}