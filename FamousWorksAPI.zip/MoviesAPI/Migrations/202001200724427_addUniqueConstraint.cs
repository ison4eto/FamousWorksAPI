namespace MoviesAPI.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class addUniqueConstraint : DbMigration
    {
        public override void Up()
        {
        }
        
        public override void Down()
        {
        }
    }
}
