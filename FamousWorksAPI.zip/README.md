# FamousWorksWebAPI

•	Project using REST architecture
•	An api providing inserting, reading, updating and deleting objects from database
